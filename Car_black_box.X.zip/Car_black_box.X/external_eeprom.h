/*Header file for External EEPROM*/
#ifndef external
#define external

/*Slave id's macro's of External EEPROM*/
#define SLAVE_READ_E		0xA1
#define SLAVE_WRITE_E		0xA0

/*function prototype's*/
void write_external_eeprom(unsigned char address1,  unsigned char data);
unsigned char read_external_eeprom(unsigned char address1);

#endif
