/***********************************CAR BLACK BOX*************************************/
/*
 * Name : Samarth Rajendra Sangar
 * Date : 07/11/2024
 * Project Name : Car black box
 *                In this project we storing the event to external EEPROM,
 *                downloading the event's,setting time & clearing the events 
 *                using RTC & I2C protocol.
 */

/*Including header file's*/
#include <xc.h>
#include "main.h"
#include "matrix_keypad.h"
#include "clcd.h"
#include "adc.h"
#include "i2c.h"
#include "ds1307.h"
#include "uart.h"
#include "isr.h"
#include "timer0.h"
#include "external_eeprom.h"

/*Variable & flag's for various events*/
unsigned char flag=1;
static unsigned int i=0,delay=1,EventFlag=0;
int EEPROM_Flag=0,viwe_flag=-1,sec=0;
unsigned short adc_reg_val;

/*Array of pointer for storing gear event's*/
unsigned char *gear[]={"ON","GN","GR","G1","G2","G3","G4","G5","C "};

/*Array of pointer for storing Menu event's*/
unsigned char *Menu[]={"VIEW LOG","SET TIME","DOWNLOAD LOG","CLEAR LOG"};

/*Array for storing EEPROM address to featch & store event's*/
unsigned int Add[]={0x00,0x10,0x20,0x30,0x40,0x50,0x60,0x70,0x80,0x90};

/*Array for storing RTC time & storing event's*/
unsigned char clock_reg[3];
unsigned char time[9];
unsigned char Event[11];

/*Function to get RTC values for the clock*/
static void get_time(void)
{
    /*Reading the RTC clock values*/
	clock_reg[0] = read_ds1307(HOUR_ADDR);
	clock_reg[1] = read_ds1307(MIN_ADDR);
	clock_reg[2] = read_ds1307(SEC_ADDR);
    
    /*Storing the RTC clock values*/
	if (clock_reg[0] & 0x40)
	{
		time[0] = '0' + ((clock_reg[0] >> 4) & 0x01);
		time[1] = '0' + (clock_reg[0] & 0x0F);
	}
	else
	{
		time[0] = '0' + ((clock_reg[0] >> 4) & 0x03);
		time[1] = '0' + (clock_reg[0] & 0x0F);
	}
	time[2] = ':';
	time[3] = '0' + ((clock_reg[1] >> 4) & 0x0F);
	time[4] = '0' + (clock_reg[1] & 0x0F);
	time[5] = ':';
	time[6] = '0' + ((clock_reg[2] >> 4) & 0x0F);
	time[7] = '0' + (clock_reg[2] & 0x0F);
	time[8] = '\0';
    
    
}

/*Function to check switch pressed events*/
void check_matrix_keypad(void)
{
	unsigned char key;
    
    /*Function call to get RTC time*/
    get_time();
    
    /*Reading switch pressed*/
    key = read_switches(STATE_CHANGE);
    
    /*Reading ADC value for speed*/
    adc_reg_val = (read_adc(CHANNEL4)/10);
    
        /*Max speed is 99*/
        if(adc_reg_val>99)
            adc_reg_val=99;
    
        /*Printing time, gear & speed on CLCD*/
        clcd_print("  TIME    EV  SP", LINE1(0));
        clcd_print(time, LINE2(0));
        clcd_print(gear[i], LINE2(10));
        clcd_putch('0'+(adc_reg_val/10), LINE2(14));
        clcd_putch('0'+(adc_reg_val%10), LINE2(15));
        
        /*Make some delay*/
        if(delay-->10)
        {
            delay=1;
            return;
        }
        
        /*checking switch pressed event's for the gear change printing on CLCD*/
        if(key==MK_SW1 && (i<=7 || flag==4))
        {
            EventFlag=1;
            delay=50;
            if(flag==4)
                i=0;
            i++;
            flag=1;
            if(i==8)
                i=7;
        }
        if(key==MK_SW2 && i>=1 && flag!=4)
        {
            EventFlag=1;
            delay=50;
            flag=2;
            i--;
            if(i==0)
                i=1;
        }
        if(key==MK_SW3 && flag!=4)
        {
            EventFlag=1;
            delay=50;
            i=8;
            flag=4;
        }
        /*Check switch 11 for menu dashboard*/
        if(key==MK_SW11)
        {
            clcd_print("                ", LINE1(0));
            clcd_print("                ", LINE2(0));
            clcd_putch('*', LINE1(0));
           
            int Manuflag=0,backchcek=0;
            /*LOOP for continue dashboard printing on CLCD*/
            while(1)
            {
                /*Checking Flag value for particular event select*/
                if(Manuflag>=3)
                    Manuflag=3;
                else if(Manuflag<=0)
                    Manuflag=0;
                
                /*Based on event select printing * on CLCD*/
                if(Manuflag<=1)
                {
                    if(backchcek>1)
                    {
                        clcd_putch(' ', LINE1(0));
                        clcd_putch('*', LINE2(0));
                        backchcek=0;
                    }
                    clcd_print(Menu[0], LINE1(1));
                    clcd_print(Menu[1], LINE2(1));
                }
                else if(Manuflag==2)
                {
                    clcd_putch('*', LINE1(0));
                    clcd_putch(' ', LINE2(0));
                    clcd_print(Menu[2], LINE1(1));
                    clcd_print(Menu[3], LINE2(1));
                }
                else
                {
                    clcd_print(Menu[2], LINE1(1));
                    clcd_print(Menu[3], LINE2(1));
                }
                
                /*Checking switch pressed for change select menu*/
                key = read_switches(STATE_CHANGE);
                
                /*switch 1 for reverse back to previous event*/
                if(key==MK_SW1)
                {
                    clcd_print("                ", LINE1(0));
                    clcd_print("                ", LINE2(0));
                    clcd_putch('*', LINE1(0));
                    clcd_putch(' ', LINE2(0));
                    Manuflag--;
                    if(Manuflag>=1)
                        backchcek++;
                }
                /*switch 2 for goto next previous event*/
                else if(key==MK_SW2)
                {
                    clcd_print("                ", LINE1(0));
                    clcd_print("                ", LINE2(0));
                    clcd_putch(' ', LINE1(0));
                    clcd_putch('*', LINE2(0));
                    Manuflag++;
                }
                /*switch 12 for reverse back to main dashboard*/
                else if(key==MK_SW12)
                {
                    clcd_print("                ", LINE1(0));
                    clcd_print("                ", LINE2(0));
                    break;
                }
                else if(Manuflag==0 && key==MK_SW11)
                {
                    /*If view menu select then call function*/
                    View_Log();
                    clcd_print("*               ", LINE1(0));
                    clcd_print("                ", LINE2(0));
                    Manuflag=0,backchcek=0;
                }
                else if(Manuflag==1 && key==MK_SW11)
                {
                    /*If Set time menu select then call function*/
                    clcd_print("HH:MM:SS        ", LINE1(0));
                    clcd_print("                ", LINE2(0));
                    if(SET_TIME()==0)
                    {
                        clcd_print("                ", LINE1(0));
                        clcd_print("                ", LINE2(0));
                        break;
                    }
                    clcd_print("*               ", LINE1(0));
                    clcd_print("                ", LINE2(0));
                    Manuflag=0,backchcek=0;
                }
                else if(Manuflag==2 && key==MK_SW11)
                {
                    /*If download menu select then call function*/
                    Download_log();
                    clcd_print("*               ", LINE1(0));
                    clcd_print("                ", LINE2(0));
                    Manuflag=0,backchcek=0;
                }
                else if(Manuflag==3 && key==MK_SW11)
                {
                    /*If Clearing events by clearing flag values*/
                    clcd_print("CLEARING LOG'S  ", LINE1(0));
                    clcd_print("   JUST A MINUTE", LINE2(0));
                    for(unsigned long long int delay=0; delay++<200000;);
                    EEPROM_Flag=0;
                    viwe_flag=-1;
                    clcd_print("*               ", LINE1(0));
                    clcd_print("                ", LINE2(0));
                    Manuflag=0,backchcek=0;
                }
            }
        }
        /*if switch pressed & flag is set then store events into EEPROM*/
        if(EventFlag==1)
        {
            EventFlag=0;
            int j=0;
            unsigned int add=Add[EEPROM_Flag++];
            viwe_flag++;
            /*Overriding the events after 10 events store*/
            if(viwe_flag>=10)
            {
                viwe_flag=9;
                unsigned int count=0,ADD1=Add[count],ADD2=Add[count+1];
                unsigned char Copy;
                for(int k=0; k<11; k++)
                {
                    if(k==10)
                    {
                        count++;
                        if(count==9)
                            break;
                        k=0;
                        ADD1=Add[count];
                        ADD2=Add[count+1];
                    }
                    Copy=read_external_eeprom(ADD2++);
                    write_external_eeprom(ADD1++,Copy);
                }
            }
            /*Storing events to EEPROM address*/
            while(j<8)
            {
                if(time[j]==':')
                {
                    j++;
                    continue;
                }
                write_external_eeprom(add++,time[j]);
                j++;
            }
            write_external_eeprom(add,gear[i][0]);
            write_external_eeprom(++add,gear[i][1]);
            write_external_eeprom(++add,'0'+(adc_reg_val/10));
            write_external_eeprom(++add,'0'+(adc_reg_val%10));
            
            if(EEPROM_Flag==10)
                 EEPROM_Flag=9;
        }
}

/*View long function to view events*/
int View_Log()
{
    clcd_print("#VIEW LOG :     ", LINE1(0));
    unsigned short key=0;
    int flag=0;
    
    /*Checking flag value to check events are present or not*/
    if(viwe_flag==-1)
    {
        clcd_print("NO LOG'S -->    ", LINE1(0));
        clcd_print("  TO DISPLAY  :(", LINE2(0));
        for(unsigned long long int delay=0; delay++<200000;);
        return 1;
    }
    
    unsigned int add=Add[flag++];
    clcd_print("0 ", LINE2(0));
    print_CLCD(add);
    /*Loop for continuous printing events*/
    while(1)
    {
        /*Checking switch events*/
        key = read_switches(STATE_CHANGE);
        /*If switch 1 pressed reverse back to previous event*/
        if(key==MK_SW1)
        {
            flag--;
            if(flag<=0)
                flag=0;
            
            add=Add[flag];
            
            clcd_putch('0'+flag, LINE2(0));
            clcd_putch(' ', LINE2(1));
            print_CLCD(add);
        }
        /*If switch 2 pressed goto next event*/
        if(key==MK_SW2)
        {
            if(viwe_flag>=9)
                viwe_flag=9;
            flag++;
            if(flag>=viwe_flag)
            {
                flag=viwe_flag;
            }
            add=Add[flag];
            
            clcd_putch('0'+flag, LINE2(0));
            clcd_putch(' ', LINE2(1));
            print_CLCD(add);
        }
        /*If switch 12 pressed goto menu dashboard*/
        if(key==MK_SW12)
            return 1;
    }
}

/*Function to download events in TERA TERM*/
void Download_log()
{
    unsigned int event_count=0,flag=0,add=0,j=0,space_flag=2,k=0;
    add=Add[flag];
    /*Checking flag value to check events are present or not*/
    if(viwe_flag==-1)
    {
        /*Print to tara term*/
        puts("NO LOG'S TO DOWNLOAD  :(    \n\n\r");
        /*Display on CLCD*/
        clcd_print("NO LOG'S -->     ", LINE1(0));
        clcd_print(" TO DOWNLOAD  :(", LINE2(0));
        for(unsigned long long int delay=0; delay++<200000;);
        return;
    }
    
    puts("No HH:MM:SS EV SP\n\r");
    clcd_print("DOWNLOADING LOGS", LINE1(0));
    clcd_print("  THROUGH UART..", LINE2(0));
    for(unsigned long long int delay=0; delay++<200000;);
    putch('0'+event_count);
    puts("  ");
    /*Running loop to 1-1 byte data transfer*/
    while(j<=10)
    {
        /*Condition to transfer in proper formate*/
        if(j==10)
        {
            if(event_count>=viwe_flag)
            {
                puts("\n\r");
                break;
            }
            puts("\n\r");
            event_count++;
            if(event_count>9)
                break; 
            else
            {
                j=0;
                add=Add[++flag];
                space_flag=2;
                k=0;
                putch('0'+event_count);
                puts("  ");
                continue;
            }
        }
        if(j<=5)
        {
            k++;
            if(k==3)
            {
                putch(':');
                space_flag++;
                k=1;
            }
            putch(Event[j]=(read_external_eeprom(add++)));
        }
        else
        {
            if(space_flag>4)
            {
                putch(':');
                space_flag=2;
            }
            
            space_flag++;
            if(space_flag>2)
            {
                space_flag=1;
                putch(' ');
            }
            if(j<=7)
            {
                putch(Event[j]=(read_external_eeprom(add++)));
            }
            else
            {
                putch(Event[j]=(read_external_eeprom(add++)));
            }
        }
        j++;
    }
    puts("DOWNLOAD LOG'S DONE\n\n\r");
}

/*Function call to set time*/
int SET_TIME()
{
    unsigned char HOUR0,HOUR1,MIN0,MIN1,SEC0,SEC1,flag=0,key=0,TIME_FLAG=0;
    unsigned char time_temp[9];
    
    for(int i=0; i<9; i++)
        time_temp[i]=time[i];
    /*Storing values to variables*/
    HOUR0=time[0];
    HOUR1=time[1];
    MIN0=time[3];
    MIN1=time[4];
    SEC0=time[6];
    SEC1=time[7];
    
    /*running loop for change time*/
    while(1)
    {
        /*Check switch pressed events*/
        key = read_switches(STATE_CHANGE);
        /*If switch 1 pressed then increase the value*/
        if(key==MK_SW2)
        {
            TIME_FLAG=0;
            flag++;
            if(flag>2)
                flag=0;
        }
        /*Switch 11 to store the updated time & go to main dashboard*/
        else if(key==MK_SW11)
        {
            int Hour=(((time_temp[0]-48)<<4)|(time_temp[1]-48));
            int Min=(((time_temp[3]-48)<<4)|(time_temp[4]-48));
            int Sec=(((time_temp[6]-48)<<4)|(time_temp[7]-48));
            write_ds1307(HOUR_ADDR,Hour);
            write_ds1307(MIN_ADDR,Min);
            write_ds1307(SEC_ADDR,Sec);
            return 0;
        }
        /*Switch 12 to don't save & goto Menu dashboard*/
        else if(key==MK_SW12)
            return 1;
        
        /*flag values for HOUR OR MIN OR SEC individual change*/
        if(flag==0)
        {
            if(key==MK_SW1)
            {
                HOUR1=(HOUR1+1);
                if(HOUR0==50 && HOUR1>51)
                {
                    HOUR1=48;
                    HOUR0=48;
                }
                else if(HOUR1==('0'+9))
                {
                    HOUR1=48;
                    HOUR0=(HOUR0+1); 
                }
                time_temp[0]=HOUR0;
                time_temp[1]=HOUR1;
            }
            /*For blinking the particular field*/
            if(sec%2==0)
            {
                clcd_print("  ", LINE2(0));
            }
            else
                clcd_print(time_temp, LINE2(0));  
        }
        /*Flag to change min field*/
        else if(flag==1)
        {
            if(key==MK_SW1)
            {
                MIN1=(MIN1+1);
                if(MIN0==53 && MIN1>=57)
                {
                    TIME_FLAG++;
                    if(TIME_FLAG==2)
                    {
                        TIME_FLAG=0;
                        MIN1=48;
                        MIN0=48;
                    }
                }
                else if(MIN1==('0'+9) && TIME_FLAG==0)
                {
                    MIN1=48;
                    MIN0=(MIN0+1); 
                }
                time_temp[3]=MIN0;
                time_temp[4]=MIN1;
            }
            /*For blinking the particular field*/
            if(sec%2==0)
            {
                clcd_print("  ", LINE2(3));
            }
            else
                clcd_print(time_temp, LINE2(0));  
        }
        /*Flag value for sec field change*/
        else if(flag==2)
        {
            if(key==MK_SW1)
            {
                SEC1=(SEC1+1);
                if(SEC0==53 && SEC1>=57)
                {
                    TIME_FLAG++;
                    if(TIME_FLAG==2)
                    {
                        TIME_FLAG=0;
                        SEC1=48;
                        SEC0=48;
                    }
                }
                else if(SEC1==('0'+9) && TIME_FLAG==0)
                {
                    SEC1=48;
                    SEC0=(SEC0+1); 
                }
                time_temp[6]=SEC0;
                time_temp[7]=SEC1;
            }
            /*For blinking the particular field*/
            if(sec%2==0)
            {
                clcd_print("  ", LINE2(6));
            }
            else
                clcd_print(time_temp, LINE2(0));  
        }
    }
}

/*printing events on CLCD*/
void print_CLCD(unsigned int add)
{
    unsigned int j=0,space_flag=2,k=0;
    /*Fetching 1-1 byte from external EEPROM & printing on CLCD*/
    while(j<10)
    {
        /*Some condition for printing in proper formate*/
        if(j<=5)
        {
            k++;
            if(k==3)
            {
                clcd_putch(':', LINE2(j+space_flag));
                space_flag++;
                k=1;
            }
            Event[j]=read_external_eeprom(add++);
            clcd_putch(Event[j], LINE2(j+space_flag));
        }
        else
        {
            if(space_flag>4)
            {
                clcd_putch(' ', LINE2(j+space_flag+1));
                space_flag=2;
            }
            
            space_flag++;
            if(space_flag>2)
            {
                space_flag=0;
                clcd_putch(' ', LINE2(j+4));
            }
            if(j<=7)
            {
                Event[j]=read_external_eeprom(add++);
                clcd_putch(Event[j], LINE2(j+5));
            }
            else
            {
                Event[j]=read_external_eeprom(add++);
                clcd_putch(Event[j], LINE2(j+6));
            }
        }
        j++;
    }
}

/*Initial configuration function*/
void init_config(void)
{
    /*Function's call to set configuration*/
    
	init_matrix_keypad();
	init_clcd();
    init_adc();
    init_i2c();
    init_uart();
    init_timer0();
    init_ds1307();
    
    /*Enable peripheral interrupt enable*/
    PEIE = 1;
    
    /*Enable global interrupt enable*/
    GIE = 1;
}

/*Main function */
void main(void)
{
    /*Function call for initial configuration set*/
	init_config();
    
    /*Super while loop*/
	while(1)
	{
        /*Function call for check switch pressed status*/
		check_matrix_keypad();
	}
}
