#include <xc.h>
#include "main.h"
#include "isr.h"

/*called function if intruupt occures after overflow*/
void __interrupt() isr(void)
{
	static unsigned long count;
    extern int sec;
    /*chcek timer flag set or not*/
	if (TMR0IF)
	{
        /*Make preloaded value*/
		TMR0 = TMR0 + 8;
        /*Increment count*/
		if (count++ == 20000)
		{
            /*increment sec & make count zero*/
            sec++;
            if(sec==60)
                sec=0;
			count = 0;
		}
        /*Make flag as zero*/
		TMR0IF = 0;
	}
}