/*Header file for main*/
#ifndef MAIN_H
#define MAIN_H

/*function prototype's*/
int View_Log();
int SET_TIME();
void print_CLCD(unsigned int add);
void Download_log();

#endif

